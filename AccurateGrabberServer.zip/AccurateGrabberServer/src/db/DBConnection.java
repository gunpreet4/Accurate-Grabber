
package db;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Gunpreet Singh
 */
public class DBConnection {
    	public static Connection connect()
	{
		Connection conn=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql:///usermaintenance";
			conn=DriverManager.getConnection(url,"root","");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return conn;
	}
}
