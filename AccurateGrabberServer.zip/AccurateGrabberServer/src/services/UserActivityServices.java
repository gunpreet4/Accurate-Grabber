package services;

import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UserActivityServices {
    private static String getDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd hh:mm:ss");
        Date d = new Date();
        String str = sdf.format(d);
        System.out.println(sdf.format(d));
        return sdf.format(d);
    }

    public static int addLoginTime(int Userid) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            con = DBConnection.connect();
            pstmt = con.prepareStatement("insert into useractivitymaster (userid,logintime)values(?,?)");
            pstmt.setInt(1, Userid);
            pstmt.setString(2, getDateTime());
            int i = pstmt.executeUpdate();
            if (i > 0) {
                pstmt = con.prepareStatement("select max(activityid) from useractivitymaster");
                rs = pstmt.executeQuery();
                if (rs.next()) {
                    System.out.println("rs.getInt(\"max(activityid)\") "+rs.getInt("max(activityid)"));
                    return rs.getInt("max(activityid)");
                }
            }
        } catch (Exception e) {
            System.out.println("Exception " + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                con.close();
            } catch (Exception e) {
                System.out.println("Exception infinally of getAllRecords()" + e);
            }
        }
        return 0;

    }

    public static boolean updateLogoutTime(int activityid) {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            System.out.println("actibity "+activityid);
            con = DBConnection.connect();
            pstmt = con.prepareStatement("update useractivitymaster set logouttime=? where activityid=?");

            pstmt.setString(1, getDateTime());
            pstmt.setInt(2, activityid);
            int i = pstmt.executeUpdate();
            if (i > 0) {
                return true;

            }
        } catch (Exception e) {
            System.out.println("Exception in getAllRecords()" + e);
        } finally {
            try {

                pstmt.close();
                con.close();
            } catch (Exception e) {
                System.out.println("Exception infinally of getAllRecords()" + e);
            }
        }
        return false;

    }
}
