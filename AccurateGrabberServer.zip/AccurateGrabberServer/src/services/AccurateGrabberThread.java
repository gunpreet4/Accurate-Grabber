package services;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
//import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class AccurateGrabberThread extends Thread {
    //TreeMap<String, Socket> tm = null;
    String un;
    public FileOutputStream fos = null;
    public DataInputStream dis = null;
    public File f = null, fzip = null;
    List<String> fileList;
    private static final String INPUT_ZIP_FILE = "D:\\Develop_Tech\\AccurateGrabber\\UnZip\\image.zip";
    private static final String OUTPUT_FOLDER = "D:\\Develop_Tech\\AccurateGrabber\\UnZip\\image";
    static String path = "";
//    ServerSocket ss = null;
    Socket cs = null;

    public AccurateGrabberThread(String un) {
       // this.tm = tm;
        this.un = un;
       // cs = tm.get(un);

    }

    public void run() {
        try {

           /* dis = new DataInputStream(cs.getInputStream());
            long len = dis.readLong();
            //System.out.println()
            String sr = dis.readUTF();
            path = "D:\\Develop_Tech\\AccurateGrabber\\UnZip" + sr;
            File f = new File(path);
            System.out.println("................" + f.getPath());
            fos = new FileOutputStream(f);

            System.out.println("..........test.................." + dis.available());
         
            int c;
            
            System.out.println("........lenght.............."+len);
               byte b[] = new byte[(int)len];
            int chk = 0;

            while (chk < len) {
                c = dis.read(b);
                fos.write(b, 0, c);
                chk = chk + c;
            }
            unZipIt(INPUT_ZIP_FILE, OUTPUT_FOLDER);
            System.out.println("Download completesssss ");
            System.out.println("hdvhydfhudf");
*/
        } catch (Exception e) {
            System.out.println("Exception in generateZip ");
        } finally {
            try {
                fos.close();
                cs.close();
            } catch (Exception e) {
                System.out.println("Exception in finally of Client " + e);
            }
        }
//unZipIt(INPUT_ZIP_FILE, OUTPUT_FOLDER);
    }

    public void unZipIt(String zipFile, String outputFolder) {
        System.out.println("in unzipit");
        byte[] buffer = new byte[1024];

        try {

            File folder = new File(OUTPUT_FOLDER);
            System.out.println("folder created unzip");
            if (!folder.exists()) {
                folder.mkdir();
            }

            ZipInputStream zis
                    = new ZipInputStream(new FileInputStream(zipFile));

            ZipEntry ze = zis.getNextEntry();

            while (ze != null) {

                String fileName = ze.getName();
                File newFile = new File(outputFolder + File.separator + fileName);

                System.out.println("file unzip : " + newFile.getAbsoluteFile());

                new File(newFile.getParent()).mkdirs();

                FileOutputStream fos = new FileOutputStream(newFile);

                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }

                fos.close();
                ze = zis.getNextEntry();
            }

            zis.closeEntry();
            zis.close();

            System.out.println("Done " + path);
            System.out.println(new File(path).exists() + " zip delete " + new File(path).delete());

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
}
