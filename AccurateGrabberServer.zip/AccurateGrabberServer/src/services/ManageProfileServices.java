package services;

import beans.UserBean;
import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ManageProfileServices {
static public UserBean getByUserId(int id)
	{
		Connection con =null;
		ArrayList <UserBean> al=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try{
			con=DBConnection.connect();
			pstmt=con.prepareStatement("select * from usermaster where userid=?");
                        pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			if(rs.next())
			{
				UserBean objbean = new UserBean();
				objbean.setUserid(rs.getInt("userid"));
				objbean.setUsername(rs.getString("username"));
				objbean.setPassword(rs.getString("Password"));
                                objbean.setUsertype(rs.getString("usertype"));
                                objbean.setUserstatus(rs.getBoolean("userstatus"));
                                objbean.setName(rs.getString("name"));
                                objbean.setContact(rs.getString("contact"));
                                objbean.setDob(rs.getString("dob"));
                                objbean.setEmailid(rs.getString("emailid"));
                                objbean.setAddress(rs.getString("Address"));
				return objbean;
			}
                        
		}
		catch(Exception e)
		{
			System.out.println("Exception in getAllRecords()"+e);
		}
		finally{
			try
			{
				rs.close();
				pstmt.close();
				con.close();
			}
			catch(Exception e)
			{
				System.out.println("Exception infinally of getAllRecords()"+e);
			}
		}
		return null;

	}    
}
