package services;

import beans.UserBean;
import db.DBConnection;
import email.SendSMTP;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginServices {
    public static UserBean authenticateUsers(String un, String pwd) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            con = DBConnection.connect();
            pstmt = con.prepareStatement("select usertype,userstatus ,userid,password from usermaster where username=?");
            pstmt.setString(1, un);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                if(rs.getString("password").equals(pwd))
                {
                UserBean objbean=new UserBean();
                objbean.setUserid(rs.getInt("userid"));
                 objbean.setUserstatus(rs.getBoolean("userstatus"));
                  objbean.setUsertype(rs.getString("usertype"));
                
            return objbean;
                }
            }
        }
        catch (Exception e) {
            System.out.println("Exception in getAllRecords()" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                con.close();
            } catch (Exception e) {
                System.out.println("Exception infinally of getAllRecords()" + e);
            }
        }
        return null;
    }

    public static boolean forgotPassword(String un) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            con = DBConnection.connect();
            pstmt = con.prepareStatement("select email,password from usermaster where username=?");
            pstmt.setString(1, un);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                String result = SendSMTP.sendMail(rs.getString("emailid"), "yourPassword is" + rs.getString("Password"), "Password Recovery");
                if (result.equalsIgnoreCase("sent")) {
                    return true;
                } else {
                    return false;
                }

            }
        } catch (Exception e) {
            System.out.println("Exception in getAllRecords()" + e);
        } finally {
            try {
                rs.close();
                pstmt.close();
                con.close();
            } catch (Exception e) {
                System.out.println("Exception infinally " + e);
            }
        }
return false;
    }
}
