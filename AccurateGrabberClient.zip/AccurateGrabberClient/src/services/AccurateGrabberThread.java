/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import java.util.TreeMap;

/**
 *
 * @author Gunpreet Singh
 */
public class AccurateGrabberThread extends Thread {
    TreeMap tm=null;
    String un;
    public AccurateGrabberThread(String un,TreeMap tm)
    {
        this.tm=tm;
        this.un=un;
    }
    public void run()
    {
        
    }
}
