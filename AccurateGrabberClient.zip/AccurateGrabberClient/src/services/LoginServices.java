package services;

import beans.UserBean;
import db.DBConnection;
import email.SendSMTP;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginServices {
    public static boolean forgotPassword(String un)
    {
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        try
        {
            conn=DBConnection.connect();
            stmt=conn.prepareStatement("Select emailid,usermaster from usermaster where username=?");
            stmt.setString(1, un);
            rs=stmt.executeQuery();
            if(rs.next())
            {
                String result=SendSMTP.sendMail(rs.getString("emailid"),"Your Password is "+rs.getString("password"),"Password Recovery");
                if(result.equalsIgnoreCase("sent"))
                {
                    return true;
                }
                else
                    return false;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception in forgotPassword "+e);
        }
        finally
    {
           try
           {
               conn.close();
               stmt.close();
               rs.close();
           }
           catch(Exception e)
           {
               System.out.println("Exception in finally of authenticateUsers "+e);
           }
     }
        return false;
    }
public static UserBean authenticateUsers(String un,String pwd)
{
    Connection conn=null;
    PreparedStatement stmt=null;
    ResultSet rs=null;
    try
    {
        conn=DBConnection.connect();
        stmt=conn.prepareStatement("Select username,usertype,password,userstatus,userid from usermaster where username=?");
        stmt.setString(1,un);
        rs=stmt.executeQuery();
        if(rs.next())      {
            if(pwd.equals(rs.getString("password")))
            {
                if(rs.getBoolean("userstatus"))
                {
                    UserBean obj=new UserBean();
                    obj.setUserid(rs.getInt("userid"));
                    obj.setUserstatus(rs.getBoolean("userstatus"));
                    obj.setUsername(rs.getString("username"));
                    obj.setUsertype(rs.getString("usertype"));
                    return obj;
                }
            }
        }
    }
    catch(Exception e)
    {
        System.out.println("Exception in authenticateUsers "+e);
    }
    finally
    {
           try
           {
               conn.close();
               stmt.close();
               rs.close();
           }
           catch(Exception e)
           {
               System.out.println("Exception in finally of authenticateUsers "+e);
           }
     }
    return null;
}
}
