package services;

import beans.UserBean;
import db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UserServices {
public static boolean addRecord(UserBean obj)
{
    Connection conn=null;
    PreparedStatement pstmt=null;
		try
		{
			conn=DBConnection.connect();
			pstmt=conn.prepareStatement("insert into usermaster(userid,username,password,usertype,userstatus,name,contact,Dob,emailid,address) values(?,?,?,?,?,?,?,?,?,?)");
			pstmt.setInt(1,obj.getUserid());
			pstmt.setString(2,obj.getUsername());
			pstmt.setString(3,obj.getPassword());
                        pstmt.setString(4,obj.getUsertype());
                        pstmt.setBoolean(5,obj.getUserstatus());
                        pstmt.setString(6,obj.getName());
                        pstmt.setString(7,obj.getContact());
                        pstmt.setString(8,obj.getDob());
                        pstmt.setString(9,obj.getEmailid());
                        pstmt.setString(10,obj.getAddress());
			int i=pstmt.executeUpdate();
			if(i>0)
				return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception in addEmployee()"+e);
		}
		finally
		{
			try
			{
				conn.close();
				pstmt.close();
			}
			catch(Exception e)
			{
				System.out.println("Exception in finally addEmployee()"+e);
			}
		}
		return false;
}
/*public List getRecordUsertype(String Usertype)
{
    
}
public List getRecordbyName(String Name)
{
    
}*/
public static boolean updateRecord(UserBean obj)
{
    Connection conn=null;
		PreparedStatement pstmt=null;
		try
		{
			conn=DBConnection.connect();
			pstmt=conn.prepareStatement("update usermaster set username=?,password=?,usertype=?,userstatus=?,name=?,contact=?,Dob=?,emailid=?,address=? where userid=?");
			pstmt.setString(1,obj.getUsername());
			pstmt.setString(2,obj.getPassword());
                        pstmt.setString(3,obj.getUsertype());
                        pstmt.setBoolean(4,obj.getUserstatus());
                        pstmt.setString(5,obj.getName());
                        pstmt.setString(6,obj.getContact());
                        pstmt.setString(7,obj.getDob());
                        pstmt.setString(8,obj.getEmailid());
                        pstmt.setString(9,obj.getAddress());
			pstmt.setInt(10,obj.getUserid());
			int i=pstmt.executeUpdate();
			if(i>0)
				return true;
		}
		catch(Exception e)
		{
			System.out.println("Exception in updateById() "+e);
		}
		finally
		{
			try
			{
				conn.close();
				pstmt.close();
			}
			catch(Exception e)
			{
				System.out.println("Exception in finally of updateById() "+e);
			}
		}
		return false;
}
public static int getNextId()
    {
        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        try
        {
            conn=DBConnection.connect();
            pstmt=conn.prepareStatement("select max(userid) from usermaster");
            rs=pstmt.executeQuery();
            if(rs.next())
            {
                return rs.getInt("max(userid)")+1;
            }
        }
        catch(Exception e)
        {
            System.out.println("Exception in getNextId" +e);
        }
        finally
        {
            try
            {
                conn.close();
                pstmt.close();
                rs.close();
            }
            catch(Exception e)
            {
                System.out.println("Exception in finally of getNextId "+e);
            }
        }
        return 0;
    }
public static List getAllRecords()
{
    Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		ArrayList<UserBean> al=null;
		List<UserBean> altemp=null;
		try
		{
			conn=DBConnection.connect();
			pstmt=conn.prepareStatement("select userid,username,password,usertype,userstatus,name,contact,Dob,emailid,address from usermaster");
			rs=pstmt.executeQuery();
			al=new ArrayList<UserBean>();
			while(rs.next())
			{
				UserBean obj=new UserBean();
				obj.setUserid(rs.getInt("userid"));
				obj.setUsername(rs.getString("username"));
				obj.setPassword(rs.getString("password"));
                                obj.setUsertype(rs.getString("usertype"));
                                obj.setUserstatus(rs.getBoolean("userstatus"));
                                obj.setName(rs.getString("name"));
                                obj.setContact(rs.getString("contact"));
                                obj.setDob(rs.getString("Dob"));
                                obj.setEmailid(rs.getString("emailid"));
                                obj.setAddress(rs.getString("address"));
				al.add(obj);
			}
			 altemp=Collections.unmodifiableList(al);  //ArrayList can't be modified now through the reference returned
		}
		catch(Exception e)
		{
			System.out.println("Exception in getAllEmployes() "+e);
		}
		finally
		{
			try
			{
				conn.close();
				pstmt.close();
				rs.close();
			}
			catch(Exception e)
			{
				System.out.println("Exception in finally getAllEmployes() "+e);
			}
		}
		return altemp;
}
}
