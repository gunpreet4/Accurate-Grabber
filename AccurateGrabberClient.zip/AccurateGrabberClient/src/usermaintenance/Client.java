package usermaintenance;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.Socket;

public class Client {

    Socket cs = null;
    DataOutputStream dos = null;
    FileInputStream fis = null;

    public Client(String name,String username) {
        try {
            cs = new Socket("127.0.0.1", 1234);
            dos = new DataOutputStream(cs.getOutputStream());
            File f = new File(name);
            dos.writeUTF(username);
            System.out.println("name file " + name);
            System.out.println("Uploading Begins.........." + name);
            if (f.exists()) {
                Long l = f.length();
                //System.out.println(l);
                dos.writeLong(l);
                dos.writeUTF(f.getName());
                FileInputStream fis = new FileInputStream(f);
                byte b[] = new byte[4096];
                int c = 0;
                while ((c = fis.read(b)) != -1) {
                    dos.write(b, 0, c);
                }
                fis.close();
                System.out.println("Uploading Done");
            }
            System.out.println("Data sent Successfully ");
        } //                System.out.println(f.getPath());
        //                File fl = new File(f.getPath());
        //                System.out.println("fi "+fl.exists());
        //                File[] file = fl.listFiles();
        //                System.out.println(file.length);
        //                for (File fil : file) {
        //                    System.out.println("delete " + fil.delete());
        //                }
        //                fl.delete();
        //                fzip.delete();
        //                System.out.println("deleted");
        catch (Exception e) {
            System.out.println("Exception in Client " + e);
        } finally {
            try {
                cs.close();
                //	ss.close();
//		dos.close();

                fis.close();
                dos.close();
            } catch (Exception e) {
                System.out.println("Exception in finally of Server " + e);
            }
        }
    }
}
