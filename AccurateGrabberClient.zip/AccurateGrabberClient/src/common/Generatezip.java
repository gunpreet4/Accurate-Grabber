/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package common;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.Socket;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 *
 * @author Gunpreet Singh
 */
public class Generatezip {
    public File f = null, fzip = null;
    public FileInputStream fis = null;
    private FileOutputStream fout = null;
   // public DataOutputStream dos = null;

    Socket cs = null;

    public Generatezip(File filepath) {
        this.f = filepath;
        System.out.println("......" + f);
       // this.cs = skt;
        zip();
    }

    public String zip() {
        FileInputStream fin = null;
        ZipOutputStream zout=null;
        String zipFile = "D:\\Develop_Tech\\AccurateGrabber\\Zip\\image.zip";
        try {
            String sourceDirectory = f.getPath();
            byte[] buffer = new byte[1024];
            fout = new FileOutputStream(fzip = new File(zipFile));
             zout = new ZipOutputStream(fout);
            File dir = new File(sourceDirectory);
            if (dir.isFile()) {
                System.out.println(sourceDirectory + "is not a file");
            } else {
                File[] files = dir.listFiles();
                System.out.println("files " + files.length);
                for (int i = 0; i < files.length; i++) {
                    System.out.println("adding" + files[i].getName());
                    fin = new FileInputStream(files[i]);
                    zout.putNextEntry(new ZipEntry(files[i].getName()));
                    int length;
                    while ((length = fin.read(buffer)) > 0) {
                        zout.write(buffer, 0, length);
                        //delete(f);
                    }
                    zout.closeEntry();
                    fout.close();
                    // fin.close();
                    //   zout.close();

                    //System.out.println("fi " + f.exists());

                    System.out.println("zipfile has been created");
//                  
                }
            }
        }
    catch(Exception e)
    {
        System.out.println("Exception in Zip "+e);
    }
    finally
    {
        try
        {
            fin.close();
            //fout.close();
           // zout.close();
        }
        catch(Exception e)
        {
            System.out.println("Exception in finally of zip "+e);
        }
    }
        return zipFile;
    }
    
}

                // fout.close();

                /*dos = new DataOutputStream(cs.getOutputStream());
                fis = new FileInputStream("D:\\Develop_Tech\\AccurateGrabber2\\Zip");
                System.out.println("..........datttttttt.................." + fis.available());
                dos.writeUTF(fzip.getName());
                int c;
                long l = new File("D:\\Develop_Tech\\AccurateGrabber2\\Zip\\image.zip").length();
                int chk = 0;
                byte b[] = new byte[(int) l];
                dos.writeLong(l);
                while (chk < l) {
                    c = fis.read(b);
                    dos.write(b, 0, c);
                    chk = chk + c;
                }
                System.out.println("Data sent Successfully ");

//                System.out.println(f.getPath());
//                File fl = new File(f.getPath());
//                System.out.println("fi "+fl.exists());
//                File[] file = fl.listFiles();
//                System.out.println(file.length);
//                for (File fil : file) {
//                    System.out.println("delete " + fil.delete());
//                }
//                fl.delete();
//                fzip.delete();
//                System.out.println("deleted");
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                cs.close();
                //	ss.close();
//		dos.close();

                fis.close();
                fout.close();
            } catch (Exception e) {
                System.out.println("Exception in finally of Server " + e);
            }
        }
return zipFile;
    }
}*/
