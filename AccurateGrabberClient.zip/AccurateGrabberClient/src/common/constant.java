/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package common;

/**
 *
 * @author Gunpreet Singh
 */
public class constant {
    public static final String CLIENT__PATH="D:\\Develop_Tech\\AccurateGrabber\\ScreenShot\\";
}
