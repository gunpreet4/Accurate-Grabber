/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package common;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author Gunpreet Singh
 */
public class ScreenShot extends Thread {
    public File f = null;
    public static boolean flag=false;

    public ScreenShot(File filepath) {
        this.f = filepath;
        System.out.println("......"+f.getPath());
    }

    
    public void run() {
        {
         flag=true;   
            while (flag) {
                float min=0,max=10;
                int random=(int)(max * Math.random() +min);
                try {
                    Robot robot = new Robot();
                    String format = "jpg";

                    long file = System.currentTimeMillis();
                    String skt = String.valueOf(file);
                    String fileName = f.getPath()+"\\"+ skt + "." + format;
                    System.out.println(fileName);
                    Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
                    BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
                    ImageIO.write(screenFullImage, format, new File(fileName));

                    Thread.sleep(random*1000);

                } catch (Exception e) {
                    System.out.println(e);
                }
               
            }
        }

    }
}
